package com.amrita.jpl.cys21076.practice.DSA;

public class ArrayExample {
    public static void main(String[] args) {
        String[] rollNumbers = {"CB.EN.U4CYS22021", "CB.EN.U4CYS22022", "CB.EN.U4CYS22023", "CB.EN.U4CYS22024", "CB.EN.U4CYS22025"};

        for (String rollNumber : rollNumbers) {
            System.out.println(rollNumber);
        }
    }
}

