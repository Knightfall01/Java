package com.amrita.jpl.cys21076.p1;

public class Main {
    public static void main(String[] args) {
        menu.main(args); // Calling the main method from the menu class.
    }
}