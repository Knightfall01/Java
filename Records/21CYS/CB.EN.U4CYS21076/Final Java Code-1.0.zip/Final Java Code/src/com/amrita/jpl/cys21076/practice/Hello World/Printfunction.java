public class Printfunction {
  public static void main(String[] args) {
    
    System.out.println("Let's play hide and seek.");
    System.out.print("Three...");
    System.out.print("Two...");
    System.out.println("One...");
    System.out.println("Ready or not, here I come!");


  }
}
